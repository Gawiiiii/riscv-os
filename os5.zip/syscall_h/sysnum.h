#ifndef __SYSNUM_H__
#define __SYSNUM_H__

#define SYS_brk          1
#define SYS_mmap         2
#define SYS_munmap       3
#define SYS_copyin       4
#define SYS_copyout      5
#define SYS_copyinstr    6

#endif