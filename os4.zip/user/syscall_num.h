
#define SYS_print 0   // 系统调用测试