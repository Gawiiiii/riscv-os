// make qemu 时这个文件总会被重写
// 所以写了啥无所谓
unsigned char initcode[] = {};
unsigned int initcode_len = 0;